package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val val1 = findViewById<EditText>(R.id.val1)
        val val2 = findViewById<EditText>(R.id.val2)
        val result = findViewById<TextView>(R.id.result)

        val nextScreenButton = findViewById<Button>(R.id.nextScreenButton)
        val addButton = findViewById<Button>(R.id.add)
        val subButton = findViewById<Button>(R.id.sub)
        val mulButton = findViewById<Button>(R.id.mul)
        val divButton = findViewById<Button>(R.id.div)

        fun calculate(operation: (Int, Int) -> Int, operationName: String) {
            val text1 = val1.text.toString()
            val text2 = val2.text.toString()

            if (text1.isNotEmpty() && text2.isNotEmpty()) {
                try {
                    val num1 = text1.toInt()
                    val num2 = text2.toInt()

                    if (operationName == "Div" && num2 == 0) {
                        result.text = "Cannot divide by zero"
                    } else {
                        val temp = operation(num1, num2).toString()
                        result.text = temp
                        Toast.makeText(this, "$operationName result: $temp", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: NumberFormatException) {
                    result.text = "Please enter valid numbers"
                }
            } else {
                result.text = "Fields cannot be empty"
            }
        }

        addButton.setOnClickListener { calculate({ a, b -> a + b }, "Sum") }
        subButton.setOnClickListener { calculate({ a, b -> a - b }, "Subtraction") }
        mulButton.setOnClickListener { calculate({ a, b -> a * b }, "Multiplication") }
        divButton.setOnClickListener { calculate({ a, b -> a / b }, "Div") }

        nextScreenButton.setOnClickListener {
            val intent = Intent(this, MainActivity2::class.java)
            intent.putExtra("message", result.text.toString()) // Passing result to second screen
            startActivity(intent)
        }
    }
}
